package com.example.finalrecord;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import com.example.finalrecord.barang;
import static android.text.TextUtils.isEmpty;

public class expenses extends AppCompatActivity {
    private Button btSubmit;
    private EditText txtcategory;
    private EditText txtamount;
    private EditText txtcaption;

    private DatePickerDialog datePickerDialog;
    private SimpleDateFormat dateFormatter;
    private TextView tvDateResult;
    private Button btDatePicker;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expenses);
        //Membuat FullScreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // inisialisasi fields EditText dan Button
        txtcategory = (EditText) findViewById(R.id.txtcategory);
        txtamount = (EditText) findViewById(R.id.txtamount);
        txtcaption = (EditText) findViewById(R.id.txtcaption);
        btSubmit = (Button) findViewById(R.id.btnsimpan);

        /**
         * Kita menggunakan format tanggal dd-MM-yyyy
         * jadi nanti tanggal nya akan diformat menjadi
         * misalnya 01-12-2017
         */
        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);

        tvDateResult = (TextView) findViewById(R.id.tv_dateresult);
        btDatePicker = (Button) findViewById(R.id.bt_datepicker);
        btDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateDialog();
            }
        });


        // kode yang dipanggil ketika tombol Submit diklik
        btSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Mengecek apakah ada data yang kosong

                if (!isEmpty(tvDateResult.getText().toString()) && !isEmpty(txtcategory.getText().toString()) && !isEmpty(txtamount.getText().toString()) && !isEmpty(txtcaption.getText().toString()))
                    submitBarang(new barang(tvDateResult.getText().toString(), txtcategory.getText().toString(), txtamount.getText().toString(), txtcaption.getText().toString()));
                else
                    Toast.makeText(expenses.this, "Data tidak boleh kosong", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDateDialog() {
        /**
         * Calendar untuk mendapatkan tanggal sekarang
         */
        Calendar newCalendar = Calendar.getInstance();

        /**
         * Initiate DatePicker dialog
         */
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                /**
                 * Method ini dipanggil saat kita selesai memilih tanggal di DatePicker
                 */

                /**
                 * Set Calendar untuk menampung tanggal yang dipilih
                 */
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);

                /**
                 * Update TextView dengan tanggal yang kita pilih
                 */
                tvDateResult.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        /**
         * Tampilkan DatePicker dialog
         */
        datePickerDialog.show();
    }


    private boolean isEmpty(String s) {
        // Cek apakah ada fields yang kosong, sebelum disubmit
        return TextUtils.isEmpty(s);
    }

    private void submitBarang(barang barang) {
/**
 * Ini adalah kode yang digunakan untuk mengirimkan data ke Firebase Realtime Database
 * dan juga kita set onSuccessListener yang berisi kode yang akan dijalankan
 * ketika data berhasil ditambahkan
 */

        //Mendapatkan UserID dari pengguna yang Terautentikasi
        auth = FirebaseAuth.getInstance(); //Mendapakan Instance Firebase Autentifikasi
        //Mendapatkan UserID dari pengguna yang Terautentikasi
        String getUserID = auth.getCurrentUser().getUid();
        //Mendapatkan Instance dari Database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference getReference;
        getReference = database.getReference(); // Mendapatkan Referensi dari Database

        getReference.child("Pengeluaran").child(getUserID).child("Users").push().setValue(barang).addOnSuccessListener(this, new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                tvDateResult.setText("");
                txtamount.setText("");
                txtcaption.setText("");
                txtcategory.setText("");
                Toast.makeText(expenses.this, "Data berhasil ditambahkan", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(expenses.this, MyListData.class));
            }
        });
    }

}
