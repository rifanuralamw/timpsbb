package com.example.finalrecord;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class financialreport extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_financialreport);
        //Membuat FullScreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void lihatdataexpensas(View view) {
        startActivity(new Intent(financialreport.this, MyListData.class));
    }

    public void lihatdataincome(View view) {
        startActivity(new Intent(financialreport.this, MyListDataPemasukan.class));
    }
}