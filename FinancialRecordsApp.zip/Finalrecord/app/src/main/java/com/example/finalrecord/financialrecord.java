package com.example.finalrecord;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class financialrecord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_financialrecord);
        //Membuat FullScreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void addincome(View view) {
        Intent intent = new Intent(financialrecord.this, income.class);
        startActivity(intent);

    }
    public void addexpenses(View view) {
        startActivity(new Intent(financialrecord.this, expenses.class));
    }

    public void register(View view) {
    }
}
