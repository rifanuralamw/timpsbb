package com.example.finalrecord;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class updateDataPemasukan extends AppCompatActivity {

    private DatePickerDialog datePickerDialog;
    private SimpleDateFormat dateFormatter;
    private Button btDatePicker;

    //Deklarasi Variable
    private TextView tglBaru;
    private EditText kategoriBaru, jumlahBaru, keteranganBaru;
    private Button update;


    private DatabaseReference database;
    private FirebaseAuth auth;
    private String cekTanggal, cekKategori, cekJumlah, cekKeterangan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.updatedata);
        //Membuat FullScreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);

        tglBaru = (TextView) findViewById(R.id.new_dateresult);
        btDatePicker = (Button) findViewById(R.id.new_datepicker);
        btDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateDialog();
            }
        });

        kategoriBaru = findViewById(R.id.new_txtcategory);
        jumlahBaru = findViewById(R.id.new_txtamount);
        keteranganBaru = findViewById(R.id.new_txtcaption);
        update = findViewById(R.id.btn_update);

        //Mendapatkan Instance autentikasi dan Referensi dari Database
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();
        getData();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Mendapatkan Data yang akan dicek
                cekTanggal = tglBaru.getText().toString();
                cekKategori = kategoriBaru.getText().toString();
                cekJumlah = jumlahBaru.getText().toString();
                cekKeterangan = keteranganBaru.getText().toString();

                //Mengecek agar tidak ada data yang kosong, saat proses update
                if(isEmpty(cekTanggal) || isEmpty(cekKategori) || isEmpty(cekJumlah) || isEmpty(cekKeterangan)){
                    Toast.makeText(updateDataPemasukan.this, "Data tidak boleh ada yang kosong", Toast.LENGTH_SHORT).show();
                }else {
                    /*
                      Menjalankan proses update data.
                      Method Setter digunakan untuk mendapakan data baru yang diinputkan User.
                    */
                    barang setData = new barang();
                    setData.setTanggal(tglBaru.getText().toString());
                    setData.setKategori(kategoriBaru.getText().toString());
                    setData.setJumlah(jumlahBaru.getText().toString());
                    setData.setKeterangan(keteranganBaru.getText().toString());
                    updatePemasukan(setData);
                }
            }
        });
    }

    private void showDateDialog() {
        /**
         * Calendar untuk mendapatkan tanggal sekarang
         */
        Calendar newCalendar = Calendar.getInstance();

        /**
         * Initiate DatePicker dialog
         */
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                /**
                 * Method ini dipanggil saat kita selesai memilih tanggal di DatePicker
                 */

                /**
                 * Set Calendar untuk menampung tanggal yang dipilih
                 */
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);

                /**
                 * Update TextView dengan tanggal yang kita pilih
                 */
                tglBaru.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        /**
         * Tampilkan DatePicker dialog
         */
        datePickerDialog.show();
    }

    // Mengecek apakah ada data yang kosong, sebelum diupdate
    private boolean isEmpty(String s){
        return TextUtils.isEmpty(s);
    }

    //Menampilkan data yang akan di update
    private void getData(){
        //Menampilkan data dari item yang dipilih sebelumnya
        final String getTanggal = getIntent().getExtras().getString("dataTanngal");
        final String getKategori = getIntent().getExtras().getString("dataKategori");
        final String getJumlah = getIntent().getExtras().getString("dataJumlah");
        final String getKeterangan = getIntent().getExtras().getString("dataKeterangan");

        tglBaru.setText(getTanggal);
        kategoriBaru.setText(getKategori);
        jumlahBaru.setText(getJumlah);
        keteranganBaru.setText(getKeterangan);
    }

    //Proses Update data yang sudah ditentukan
    private void updatePemasukan(barang pemasukan){
        String userID = auth.getUid();
        String getKey = getIntent().getExtras().getString("getPrimaryKey");
        database.child("Pemasukan")
                .child(userID)
                .child("Users")
                .child(getKey)
                .setValue(pemasukan)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        tglBaru.setText("");
                        jumlahBaru.setText("");
                        kategoriBaru.setText("");
                        keteranganBaru.setText("");
                        Toast.makeText(updateDataPemasukan.this, "Data Berhasil diubah", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }
}
