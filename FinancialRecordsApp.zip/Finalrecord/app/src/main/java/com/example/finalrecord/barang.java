package com.example.finalrecord;
import com.google.firebase.database.IgnoreExtraProperties;

import java.io.Serializable;

@IgnoreExtraProperties
public class barang implements Serializable{
    private String kategori;
    private String jumlah;
    private String keterangan;
    private String tanggal;
    private String key;

    public barang(){

    }
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKategori() {

        return kategori;
    }

    public void setKategori(String kategori) {

        this.kategori = kategori;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getKeterangan() {

        return keterangan;
    }

    public void setKeterangan(String keterangan) {

        this.keterangan = keterangan;
    }


    public String getTanggal() {

        return tanggal;
    }

    public void setTanggal(String tanggal) {

        this.tanggal = tanggal;
    }

    @Override
    public String toString() {
        return " "+kategori+"\n" +
                " "+tanggal+"\n" +
                " "+jumlah+"\n" +
                " "+keterangan;
    }

    public barang(String tgl, String kt, String jml, String ket){
        kategori = kt;
        jumlah = jml;
        keterangan = ket;
        tanggal = tgl;
    }
}

